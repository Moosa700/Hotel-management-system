import {
  Award,
  Users,
  BedDouble,
  Star,
  ShieldCheck,
  HeartHandshake,
  ArrowRight,
} from "lucide-react";

export default function About() {
  const stats = [
    {
      number: "10+",
      label: "Years of Excellence",
    },
    {
      number: "120+",
      label: "Luxury Rooms",
    },
    {
      number: "25K+",
      label: "Happy Guests",
    },
    {
      number: "4.9★",
      label: "Guest Rating",
    },
  ];

  const values = [
    {
      icon: Award,
      title: "Luxury Experience",
      description:
        "Elegant rooms, premium facilities and unforgettable hospitality designed to exceed expectations.",
    },
    {
      icon: Users,
      title: "Professional Team",
      description:
        "Our highly trained staff delivers exceptional service with warmth, professionalism and care.",
    },
    {
      icon: ShieldCheck,
      title: "Safety First",
      description:
        "24/7 security, secure access, CCTV monitoring and complete peace of mind for every guest.",
    },
    {
      icon: HeartHandshake,
      title: "Guest Satisfaction",
      description:
        "Every decision we make is focused on creating memorable experiences for our visitors.",
    },
  ];

  return (
    <div className="about-page">

      {/* HERO */}

      <section
        className="about-hero"
        style={{
          backgroundImage:
            "linear-gradient(rgba(8,40,43,.72), rgba(8,40,43,.72)), url('https://images.unsplash.com/photo-1566073771259-6a8506099945?q=80&w=2070&auto=format&fit=crop')",
        }}
      >

        <div className="container about-hero-content">

          <span className="hero-badge">
            LUXURY HOTEL EXPERIENCE
          </span>

          <h1 className="about-title">
            Where Luxury
            <br />
            Meets Comfort
          </h1>

          <p className="about-subtitle">
            LuxuryStay is dedicated to creating unforgettable
            experiences through elegant accommodations,
            exceptional hospitality, and world-class service.
          </p>

          <div className="about-buttons">

            <button className="btn-primary">
              Book Your Stay
            </button>

            <button className="btn-secondary">
              Explore Rooms
            </button>

          </div>

        </div>

      </section>
            {/* OUR STORY */}

      <section className="about-story">

        <div className="container about-story-grid">

          <div className="about-story-image">

            <img
              src="https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?q=80&w=1974&auto=format&fit=crop"
              alt="Luxury Hotel"
            />

          </div>

          <div className="about-story-content">

            <span className="section-tag">
              OUR STORY
            </span>

            <h2 className="section-title">
              Crafting Luxury Experiences Since 2015
            </h2>

            <p>
              LuxuryStay was founded with one vision — to redefine
              hospitality through elegance, comfort, and exceptional
              customer service. Every guest deserves an unforgettable
              stay, and that belief continues to inspire everything
              we do today.
            </p>

            <p>
              From beautifully designed rooms and fine dining to
              wellness facilities and personalized services, every
              detail has been thoughtfully curated to provide a
              world-class luxury experience.
            </p>

            <div className="about-feature-card">

              <BedDouble
                size={60}
                className="feature-icon"
              />

              <div>

                <h3>Premium Hospitality</h3>

                <p>
                  Elegant accommodations, luxury suites,
                  gourmet dining, spa treatments, fitness
                  center, conference halls, swimming pools,
                  and personalized guest services.
                </p>

              </div>

            </div>

          </div>

        </div>

      </section>

      {/* STATISTICS */}

      <section className="about-stats">

        <div className="container stats-grid">

          {stats.map((item) => (

            <div
              key={item.label}
              className="stat-card"
            >

              <h2>{item.number}</h2>

              <p>{item.label}</p>

            </div>

          ))}

        </div>

      </section>
            {/* WHY CHOOSE US */}

      <section className="about-values">

        <div className="container">

          <span className="section-tag center">
            WHY CHOOSE US
          </span>

          <h2 className="section-title">
            Exceptional Hospitality,
            Every Step of the Way
          </h2>

          <p className="section-subtitle">
            We combine luxury, comfort, and personalized service to
            ensure every guest enjoys an unforgettable experience
            from check-in to check-out.
          </p>

          <div className="values-grid">

            {values.map((value) => {

              const Icon = value.icon;

              return (

                <div
                  key={value.title}
                  className="value-card"
                >

                  <div className="value-icon">

                    <Icon size={42} />

                  </div>

                  <h3>
                    {value.title}
                  </h3>

                  <p>
                    {value.description}
                  </p>

                </div>

              );

            })}

          </div>

        </div>

      </section>

      {/* EXPERIENCE SECTION */}

      <section className="about-experience">

        <div className="container experience-grid">

          <div className="experience-content">

            <span className="section-tag">
              THE LUXURYSTAY EXPERIENCE
            </span>

            <h2>
              Every Stay Is Designed
              To Feel Extraordinary
            </h2>

            <p>
              From the moment you arrive, every detail is carefully
              planned to provide comfort, elegance and exceptional
              hospitality. Whether you're travelling for business,
              leisure or a special celebration, our dedicated team
              ensures every moment exceeds expectations.
            </p>

            <ul className="experience-list">

              <li>✓ Spacious Luxury Suites</li>

              <li>✓ Award-Winning Restaurant</li>

              <li>✓ Rooftop Infinity Pool</li>

              <li>✓ Spa & Wellness Center</li>

              <li>✓ Airport Pickup Service</li>

              <li>✓ 24/7 Concierge Support</li>

            </ul>

          </div>

          <div className="experience-card">

            <Star
              size={70}
              className="experience-star"
            />

            <h3>Luxury You Can Trust</h3>

            <p>
              Trusted by thousands of travelers from around the
              world, LuxuryStay continues to deliver exceptional
              experiences with world-class comfort and outstanding
              hospitality.
            </p>

          </div>

        </div>

      </section>

            {/* MISSION & VISION */}

      <section className="about-mission">

        <div className="container">

          <span className="section-tag center">
            OUR PURPOSE
          </span>

          <h2 className="section-title">
            Inspired By Excellence
          </h2>

          <p className="section-subtitle">
            Our mission is to redefine luxury hospitality through
            innovation, personalized service, and unforgettable
            guest experiences.
          </p>

          <div className="mission-grid">

            <div className="mission-card">

              <Star
                size={55}
                className="mission-icon"
              />

              <h3>Our Mission</h3>

              <p>
                To deliver exceptional hospitality by combining
                luxury, comfort and personalized services that
                exceed guest expectations and create unforgettable
                memories.
              </p>

            </div>

            <div className="mission-card">

              <Award
                size={55}
                className="mission-icon"
              />

              <h3>Our Vision</h3>

              <p>
                To become one of the world's most admired luxury
                hotel brands, recognized for excellence,
                innovation, sustainability and customer
                satisfaction.
              </p>

            </div>

          </div>

        </div>

      </section>

      {/* CALL TO ACTION */}

      <section className="about-cta">

        <div className="container">

          <div className="cta-box">

            <span className="hero-badge">
              EXPERIENCE TRUE LUXURY
            </span>

            <h2>
              Your Perfect Stay
              <br />
              Starts Here
            </h2>

            <p>
              Whether you're planning a relaxing vacation,
              business trip or special celebration,
              LuxuryStay promises a memorable experience with
              elegant accommodations and world-class service.
            </p>

            <div className="cta-buttons">

              <button className="btn-primary">
                Book Your Stay
              </button>

              <button className="btn-secondary">
                View Our Rooms
              </button>

            </div>

          </div>

        </div>

      </section>

    </div>
  );
}