import {
  Mail,
  Phone,
  MapPin,
  Clock,
  Send,
} from "lucide-react";

export default function Contact() {
  return (
    <div className="bg-gray-50">

      {/* Hero */}

      <section className="bg-[#0F3D3E] py-24 text-white">
        <div className="mx-auto max-w-7xl px-6 text-center">

          <h1 className="text-5xl font-bold">
            Contact Us
          </h1>

          <p className="mx-auto mt-6 max-w-3xl text-lg text-gray-200">
            We'd love to hear from you. Whether you have a question,
            reservation inquiry, or feedback, our team is here to help.
          </p>

        </div>
      </section>

      {/* Contact Section */}

      <section className="mx-auto grid max-w-7xl gap-10 px-6 py-20 lg:grid-cols-2">

        {/* Contact Info */}

        <div className="space-y-8">

          <h2 className="text-4xl font-bold text-[#0F3D3E]">
            Get In Touch
          </h2>

          <p className="text-lg leading-8 text-gray-600">
            Visit our luxury hotel or contact us through any of the
            following channels. We are available 24/7 to assist you.
          </p>

          <div className="space-y-6">

            <div className="flex items-center gap-5 rounded-2xl bg-white p-6 shadow">
              <MapPin className="text-[#D4A24C]" size={34} />
              <div>
                <h3 className="font-semibold text-[#0F3D3E]">
                  Address
                </h3>
                <p className="text-gray-600">
                  Luxury Avenue, Dubai, UAE
                </p>
              </div>
            </div>

            <div className="flex items-center gap-5 rounded-2xl bg-white p-6 shadow">
              <Phone className="text-[#D4A24C]" size={34} />
              <div>
                <h3 className="font-semibold text-[#0F3D3E]">
                  Phone
                </h3>
                <p className="text-gray-600">
                  +971 123 456 789
                </p>
              </div>
            </div>

            <div className="flex items-center gap-5 rounded-2xl bg-white p-6 shadow">
              <Mail className="text-[#D4A24C]" size={34} />
              <div>
                <h3 className="font-semibold text-[#0F3D3E]">
                  Email
                </h3>
                <p className="text-gray-600">
                  info@luxurystay.com
                </p>
              </div>
            </div>

            <div className="flex items-center gap-5 rounded-2xl bg-white p-6 shadow">
              <Clock className="text-[#D4A24C]" size={34} />
              <div>
                <h3 className="font-semibold text-[#0F3D3E]">
                  Working Hours
                </h3>
                <p className="text-gray-600">
                  Open 24 Hours • 7 Days a Week
                </p>
              </div>
            </div>

          </div>

        </div>

        {/* Contact Form */}

        <div className="rounded-3xl bg-white p-10 shadow-xl">

          <h2 className="mb-8 text-3xl font-bold text-[#0F3D3E]">
            Send a Message
          </h2>

          <form className="space-y-6">

            <div>
              <label className="mb-2 block font-medium">
                Full Name
              </label>

              <input
                type="text"
                placeholder="Enter your full name"
                className="w-full rounded-xl border p-4 focus:border-[#0F3D3E] focus:outline-none"
              />
            </div>

            <div>
              <label className="mb-2 block font-medium">
                Email Address
              </label>

              <input
                type="email"
                placeholder="Enter your email"
                className="w-full rounded-xl border p-4 focus:border-[#0F3D3E] focus:outline-none"
              />
            </div>

            <div>
              <label className="mb-2 block font-medium">
                Subject
              </label>

              <input
                type="text"
                placeholder="Subject"
                className="w-full rounded-xl border p-4 focus:border-[#0F3D3E] focus:outline-none"
              />
            </div>

            <div>
              <label className="mb-2 block font-medium">
                Message
              </label>

              <textarea
                rows={6}
                placeholder="Write your message..."
                className="w-full rounded-xl border p-4 focus:border-[#0F3D3E] focus:outline-none"
              />
            </div>

            <button
              type="submit"
              className="flex w-full items-center justify-center gap-3 rounded-xl bg-[#0F3D3E] py-4 text-lg font-semibold text-white transition hover:bg-[#0B3132]"
            >
              <Send size={20} />
              Send Message
            </button>

          </form>

        </div>

      </section>

      {/* Map Placeholder */}

      <section className="mx-auto max-w-7xl px-6 pb-20">

        <div className="flex h-[400px] items-center justify-center rounded-3xl bg-[#0F3D3E] text-center text-white shadow-xl">

          <div>

            <MapPin
              size={60}
              className="mx-auto text-[#D4A24C]"
            />

            <h2 className="mt-6 text-3xl font-bold">
              Google Maps Location
            </h2>

            <p className="mt-3 text-gray-200">
              Integrate Google Maps API here to display the hotel location.
            </p>

          </div>

        </div>

      </section>

    </div>
  );
}