import { useParams } from "@tanstack/react-router";
import { useEffect, useState } from "react";

import { getRoom } from "@/services/room.service";

export default function RoomDetails() {
  const { roomId } = useParams();

  const [room, setRoom] = useState(null);

  useEffect(() => {
    async function loadRoom() {
      const data = await getRoom(roomId);
      setRoom(data.room || data);
    }

    loadRoom();
  }, [roomId]);

  if (!room) {
    return (
      <div className="py-32 text-center">
        Loading...
      </div>
    );
  }

  return (
    <section className="container mx-auto py-20">

      <img
        src={room.image}
        className="h-[500px] w-full rounded-3xl object-cover"
      />

      <h1 className="mt-8 text-5xl font-bold">
        {room.title}
      </h1>

      <p className="mt-6 text-lg text-gray-600">
        {room.description}
      </p>

      <h2 className="mt-8 text-3xl font-bold">
        ${room.price} / Night
      </h2>

    </section>
  );
}