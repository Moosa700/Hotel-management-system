import { useState } from "react";

import { createBooking } from "@/services/booking.service";

export default function Booking() {

  const [form, setForm] = useState({
    roomId: "",
    checkIn: "",
    checkOut: "",
    guests: 1,
  });

  async function submit(e) {

    e.preventDefault();

    await createBooking(form);

    alert("Booking Created Successfully");

  }

  return (
    <section className="container mx-auto py-20">

      <form
        onSubmit={submit}
        className="mx-auto max-w-xl space-y-5 rounded-2xl bg-white p-8 shadow"
      >

        <input
          placeholder="Room ID"
          className="w-full rounded-lg border p-3"
          onChange={(e) =>
            setForm({
              ...form,
              roomId: e.target.value,
            })
          }
        />

        <input
          type="date"
          className="w-full rounded-lg border p-3"
          onChange={(e) =>
            setForm({
              ...form,
              checkIn: e.target.value,
            })
          }
        />

        <input
          type="date"
          className="w-full rounded-lg border p-3"
          onChange={(e) =>
            setForm({
              ...form,
              checkOut: e.target.value,
            })
          }
        />

        <input
          type="number"
          className="w-full rounded-lg border p-3"
          min={1}
          defaultValue={1}
          onChange={(e) =>
            setForm({
              ...form,
              guests: e.target.value,
            })
          }
        />

        <button className="w-full rounded-lg bg-primary py-4 text-white">
          Book Now
        </button>

      </form>

    </section>
  );
}