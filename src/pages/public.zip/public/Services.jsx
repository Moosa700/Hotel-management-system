import {
  BedDouble,
  UtensilsCrossed,
  Wifi,
  Dumbbell,
  Waves,
  Car,
  Coffee,
  ShieldCheck,
} from "lucide-react";

const services = [
  {
    icon: BedDouble,
    title: "Luxury Rooms",
    description:
      "Spacious and elegant rooms equipped with premium facilities for maximum comfort.",
  },
  {
    icon: UtensilsCrossed,
    title: "Fine Dining",
    description:
      "Enjoy world-class cuisine prepared by experienced chefs with international flavors.",
  },
  {
    icon: Wifi,
    title: "Free High-Speed Wi-Fi",
    description:
      "Stay connected throughout the hotel with complimentary high-speed internet.",
  },
  {
    icon: Dumbbell,
    title: "Fitness Center",
    description:
      "Modern gym equipped with the latest fitness equipment available 24/7.",
  },
  {
    icon: Waves,
    title: "Swimming Pool & Spa",
    description:
      "Relax in our luxurious pool and rejuvenate with premium spa treatments.",
  },
  {
    icon: Car,
    title: "Airport Shuttle",
    description:
      "Convenient airport pickup and drop-off service for all our guests.",
  },
  {
    icon: Coffee,
    title: "24/7 Room Service",
    description:
      "Order delicious meals and refreshments anytime during your stay.",
  },
  {
    icon: ShieldCheck,
    title: "Safe & Secure",
    description:
      "24/7 security, CCTV monitoring, and secure access for complete peace of mind.",
  },
];

export default function Services() {
  return (
    <div className="bg-gray-50">

      {/* Hero */}

      <section className="bg-[#0F3D3E] py-24 text-white">
        <div className="mx-auto max-w-7xl px-6 text-center">

          <h1 className="text-5xl font-bold">
            Our Services
          </h1>

          <p className="mx-auto mt-6 max-w-3xl text-lg text-gray-200">
            Discover premium hospitality and exceptional services
            designed to make every stay comfortable, luxurious,
            and unforgettable.
          </p>

        </div>
      </section>

      {/* Services */}

      <section className="mx-auto max-w-7xl px-6 py-20">

        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">

          {services.map((service) => {
            const Icon = service.icon;

            return (
              <div
                key={service.title}
                className="rounded-3xl bg-white p-8 shadow-lg transition hover:-translate-y-2 hover:shadow-xl"
              >
                <div className="mb-6 inline-flex rounded-full bg-[#0F3D3E]/10 p-4">
                  <Icon
                    size={36}
                    className="text-[#D4A24C]"
                  />
                </div>

                <h2 className="mb-4 text-2xl font-bold text-[#0F3D3E]">
                  {service.title}
                </h2>

                <p className="leading-7 text-gray-600">
                  {service.description}
                </p>
              </div>
            );
          })}

        </div>

      </section>

      {/* CTA */}

      <section className="bg-[#0F3D3E] py-20 text-white">

        <div className="mx-auto max-w-4xl px-6 text-center">

          <h2 className="text-4xl font-bold">
            Experience Luxury Like Never Before
          </h2>

          <p className="mt-6 text-lg text-gray-200 leading-8">
            Whether you're traveling for business or leisure,
            LuxuryStay offers exceptional hospitality, premium
            services, and unforgettable experiences.
          </p>

          <button className="mt-10 rounded-xl bg-[#D4A24C] px-8 py-4 text-lg font-semibold text-black transition hover:scale-105">
            Book Your Stay
          </button>

        </div>

      </section>

    </div>
  );
}